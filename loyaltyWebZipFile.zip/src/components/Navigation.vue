<template>
  <div class="w-full bg-black bg-opacity-80 text-white">
    <div class="max-w-[1140px] w-full mx-auto flex justify-between items-center py-4 px-6">
      <!-- Desktop: Nav + Logo inline from left to right -->
      <div v-show="!mobile" class="hidden md:flex items-center justify-center gap-8 w-full">
        <!-- Navigation Links -->
        <ul class="flex items-center gap-6 font-medium text-sm">
          <li v-for="item in navItems" :key="item.label">
            <router-link
              :to="{ name: item.route }"
              class="text-white border-b border-transparent hover:border-blue-400 hover:text-blue-400 transition-all duration-300 py-2 px-1"
            >
              {{ item.label }}
            </router-link>
          </li>
        </ul>

        <!-- Logo appears after nav -->
        <div class="ml-auto flex items-center">
          <img src="@/assets/extrabonus88.png" alt="logo" class="w-12 h-12" />
        </div>
      </div>

      <!-- Mobile: Burger Icon -->
      <div v-show="mobile" class="md:hidden flex items-center justify-between w-full px-2">
        <img src="@/assets/extrabonus88.png" alt="logo" class="w-[50px]" />
        <button
          @click="toggleMobileNav"
          class="text-white text-xl transition-transform duration-500"
          :class="{ 'rotate-180': mobileNav }"
        >
          <svg
            class="w-6 h-6"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            viewBox="0 0 24 24"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
    </div>

    <!-- Mobile Dropdown Nav -->
    <transition name="fade">
      <ul
        v-show="mobileNav"
        class="md:hidden bg-black bg-opacity-90 px-[5%] py-4 space-y-3 font-medium uppercase"
      >
        <li v-for="item in navItems" :key="'m-' + item.label">
          <router-link :to="{ name: item.route }" class="block text-sm hover:text-blue-400">
            {{ item.label }}
          </router-link>
        </li>
      </ul>
    </transition>
  </div>
</template>

<script>
export default {
  name: 'Navigation',
  data() {
    return {
      scrollPosition: 0,
      mobile: false, // hardcoded for testing
      mobileNav: false,
      navItems: [
        { label: 'Home', route: 'home' },
        { label: 'About', route: 'about' },
        { label: 'Promotion', route: '' },
        { label: 'Register', route: '' },
        { label: 'Login', route: '' },
      ],
    }
  },
  methods: {
    toggleMobileNav() {
      this.mobileNav = !this.mobileNav
      console.log('is mobile', !this.mobileNav)
    },
  },
}
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
